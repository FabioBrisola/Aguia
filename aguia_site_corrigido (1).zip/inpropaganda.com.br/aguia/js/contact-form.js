// Script para o formulário de contato
document.addEventListener('DOMContentLoaded', function() {
    const contactForm = document.getElementById('contact-form');
    const formMessage = document.getElementById('form-message');

    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Coleta os dados do formulário
            const formData = new FormData(contactForm);
            const name = formData.get('name');
            const email = formData.get('email');
            const phone = formData.get('phone');
            const service = formData.get('service');
            const message = formData.get('message');
            
            // Validação básica
            if (!name || !email || !service || !message) {
                showMessage('Por favor, preencha todos os campos obrigatórios.', 'error');
                return;
            }
            
            // Validação de email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                showMessage('Por favor, insira um e-mail válido.', 'error');
                return;
            }
            
            // Simula o envio do formulário
            showMessage('Enviando mensagem...', 'info');
            
            // Simula um delay de envio
            setTimeout(function() {
                // Cria o link do WhatsApp com a mensagem
                const whatsappMessage = `Olá! Meu nome é ${name}.%0A%0A` +
                    `E-mail: ${email}%0A` +
                    `${phone ? `Telefone: ${phone}%0A` : ''}` +
                    `Serviço de interesse: ${getServiceName(service)}%0A%0A` +
                    `Mensagem: ${message}`;
                
                const whatsappUrl = `https://wa.me/5511947552339?text=${whatsappMessage}`;
                
                // Abre o WhatsApp
                window.open(whatsappUrl, '_blank');
                
                // Mostra mensagem de sucesso
                showMessage('Mensagem preparada! Você será redirecionado para o WhatsApp para enviar sua mensagem.', 'success');
                
                // Limpa o formulário
                contactForm.reset();
            }, 1000);
        });
    }
    
    function showMessage(message, type) {
        formMessage.innerHTML = `<div class="alert alert-${type === 'error' ? 'danger' : type === 'success' ? 'success' : 'info'}">${message}</div>`;
        formMessage.style.display = 'block';
        
        // Remove a mensagem após 5 segundos
        setTimeout(function() {
            formMessage.style.display = 'none';
        }, 5000);
    }
    
    function getServiceName(serviceValue) {
        const services = {
            'automacao': 'Automação',
            'seguranca': 'Segurança',
            'alarme-incendio': 'Alarme/Incêndio',
            'cabeamento': 'Cabeamento',
            'datacenter': 'Data Center',
            'servicos-digitais': 'Serviços Digitais',
            'equipamentos': 'Equipamentos',
            'instalacao': 'Instalação',
            'outros': 'Outros'
        };
        return services[serviceValue] || serviceValue;
    }
});

